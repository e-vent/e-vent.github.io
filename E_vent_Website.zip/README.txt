E-vent

Website: e-vent.github.io

##### Description #####

This is a event-planning webapp for the general public. It helps find, plan, and join events, while considering the schedule of all guests.

##### Team #####

- Daniel Tang
- Firas Jribi
- Amayas Said Amer
- Jean-Pierre sfeir
- Marla Jazzar
